#include "07_ThreadRead.h"

int main()
{
    ThreadRead start;
}