#!/bin/sh
CLASS_DIR="./classes"

cd "$CLASS_DIR"
java peak.can.Application
